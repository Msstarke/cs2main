// Generated using https://github.com/a2x/cs2-dumper
// 2025-07-16 03:25:09.841805 UTC

namespace CS2Dumper {
    // Module: client.dll
    public static class Buttons {
        public const nint attack = 0x18518E0;
        public const nint attack2 = 0x1851970;
        public const nint back = 0x1851BB0;
        public const nint duck = 0x1851E80;
        public const nint forward = 0x1851B20;
        public const nint jump = 0x1851DF0;
        public const nint left = 0x1851C40;
        public const nint lookatweapon = 0x1A781A0;
        public const nint reload = 0x1851850;
        public const nint right = 0x1851CD0;
        public const nint showscores = 0x1A78080;
        public const nint sprint = 0x18517C0;
        public const nint turnleft = 0x1851A00;
        public const nint turnright = 0x1851A90;
        public const nint use = 0x1851D60;
        public const nint zoom = 0x1A78110;
    }
}
