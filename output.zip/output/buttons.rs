// Generated using https://github.com/a2x/cs2-dumper
// 2025-07-16 03:25:09.841805 UTC

#![allow(non_upper_case_globals, unused)]

pub mod cs2_dumper {
    // Module: client.dll
    pub mod buttons {
        pub const attack: usize = 0x18518E0;
        pub const attack2: usize = 0x1851970;
        pub const back: usize = 0x1851BB0;
        pub const duck: usize = 0x1851E80;
        pub const forward: usize = 0x1851B20;
        pub const jump: usize = 0x1851DF0;
        pub const left: usize = 0x1851C40;
        pub const lookatweapon: usize = 0x1A781A0;
        pub const reload: usize = 0x1851850;
        pub const right: usize = 0x1851CD0;
        pub const showscores: usize = 0x1A78080;
        pub const sprint: usize = 0x18517C0;
        pub const turnleft: usize = 0x1851A00;
        pub const turnright: usize = 0x1851A90;
        pub const r#use: usize = 0x1851D60;
        pub const zoom: usize = 0x1A78110;
    }
}
