// Generated using https://github.com/a2x/cs2-dumper
// 2025-07-16 03:25:09.841805 UTC

#![allow(non_upper_case_globals, non_camel_case_types, non_snake_case, unused)]

pub mod cs2_dumper {
    pub mod schemas {
        // Module: networksystem.dll
        // Class count: 1
        // Enum count: 0
        pub mod networksystem_dll {
            // Parent: None
            // Field count: 1
            pub mod ChangeAccessorFieldPathIndex_t {
                pub const m_Value: usize = 0x0; // int32
            }
        }
    }
}
