// Generated using https://github.com/a2x/cs2-dumper
// 2025-07-16 03:25:09.841805 UTC

namespace CS2Dumper.Schemas {
    // Module: host.dll
    // Class count: 2
    // Enum count: 0
    public static class HostDll {
        // Parent: CAnimScriptBase
        // Field count: 1
        public static class EmptyTestScript {
            public const nint m_hTest = 0x10; // CAnimScriptParam<float32>
        }
        // Parent: None
        // Field count: 1
        public static class CAnimScriptBase {
            public const nint m_bIsValid = 0x8; // bool
        }
    }
}
